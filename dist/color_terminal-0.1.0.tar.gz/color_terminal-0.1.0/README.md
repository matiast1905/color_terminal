# Color Printer

This package allows you to change the text color and background color of the terminal output
