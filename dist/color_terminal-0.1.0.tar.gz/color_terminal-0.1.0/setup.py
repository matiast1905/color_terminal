from setuptools import setup, find_packages

setup(
    name="color_terminal",
    version="0.1.0",
    author="Matias Taron Simoes",
    author_email="matiastaron@gmail.com",
    # url='http://pypi.python.org/pypi/PackageName/',
    license="LICENSE",
    description="Color text and background of terminal output",
    packages=find_packages(where="."),
    package_dir={"": "."},
    include_package_data=True,
)
